﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.ApplicationModel.Background;
using Windows.Devices.Geolocation;
using Windows.Storage;

namespace SampleLocationTriggers
{
    public class MyLocationTrigger : IBackgroundTask
    {
        public async void Run(IBackgroundTaskInstance taskInstance)
        {
            BackgroundTaskDeferral deferral = taskInstance.GetDeferral();
            try
            {
                Geolocator geolocator = 
                    new Geolocator();

                Geoposition geoPosition = 
                    await geolocator.GetGeopositionAsync();

                DateTime currentTime = DateTime.Now;
                var settings = ApplicationData.Current.LocalSettings;
                settings.Values["Latitude"] = geoPosition.Coordinate.Point.Position.Latitude.ToString();
                settings.Values["Longitude"] = geoPosition.Coordinate.Point.Position.Longitude.ToString();
            }
            catch (Exception ex)
            {

                var settings = ApplicationData.Current.LocalSettings;
                settings.Values["ErrorMessage"] = ex.Message; 
            }
            finally
            {
                deferral.Complete();
            }

        }
    }
}
