﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Networking.BackgroundTransfer;
using Windows.Storage;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace ServiceImprovements
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class BackgroundTransfersPriority : Page
    {
        private CancellationTokenSource cts;
        public BackgroundTransfersPriority()
        {
            this.InitializeComponent();

            cts = new CancellationTokenSource();
        }

        private void NoConstraintsDownloadBUtton_Click(object sender, RoutedEventArgs e)
        {
            CreateDownloadOperation(BackgroundTransferPriority.Default, true);

        }

        private void HighPrioDownloadButton_Click(object sender, RoutedEventArgs e)
        {
            CreateDownloadOperation(BackgroundTransferPriority.High, false);

        }

        private void RegularDownloadButton_Click(object sender, RoutedEventArgs e)
        {
            CreateDownloadOperation(BackgroundTransferPriority.Default, false);
        }


        private async void CreateDownloadOperation
            (BackgroundTransferPriority backgroundTransferPriority, bool requestUnconstrainedDownload)
        {
            Uri address;
            Uri.TryCreate(AddressTextBox.Text, UriKind.Absolute, out address);
            if (address != null)
            {

                string destinationFileName = Guid.NewGuid().ToString();

                StorageFile destinationFile;
                try
                {
                    destinationFile = await KnownFolders.VideosLibrary.CreateFileAsync(
                        destinationFileName, CreationCollisionOption.GenerateUniqueName);
                }
                catch (FileNotFoundException ex)
                {
                    return;
                }

                BackgroundDownloader backgroundDownloader = new BackgroundDownloader();
                DownloadOperation downloadOperation = backgroundDownloader.CreateDownload(address, destinationFile);

                ResultTextBox.Text += String.Format("Downloading {0} to {1} with {2} priority",
                    address.AbsoluteUri, destinationFile.Name, backgroundTransferPriority);

                downloadOperation.Priority = backgroundTransferPriority;

                if (!requestUnconstrainedDownload)
                {
                    await PerformActualDownload(downloadOperation, true);
                    return;
                }

                List<DownloadOperation> requestOperations = new List<DownloadOperation>();
                requestOperations.Add(downloadOperation);


                UnconstrainedTransferRequestResult result = await BackgroundDownloader.RequestUnconstrainedDownloadsAsync(
                    requestOperations);

                ResultTextBox.Text += String.Format("Request for unconstrained downloads has been {0}",
                     (result.IsUnconstrained ? "granted" : "denied"));

                await PerformActualDownload(downloadOperation, true);
            }
        }

        private async System.Threading.Tasks.Task PerformActualDownload(DownloadOperation downloadOperation, bool p)
        {
            try
            {
                Progress<DownloadOperation> progressCallback = new Progress<DownloadOperation>(DownloadProgress);

                await downloadOperation.StartAsync().AsTask(cts.Token, progressCallback);
                ResponseInformation response = downloadOperation.GetResponseInformation();

                ResultTextBox.Text += "Completed the download with status code: " + response.StatusCode;
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        private void DownloadProgress(DownloadOperation download)
        {
            this.Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, () =>
            {
                StatusTextBlock.Text = "Download completion: " + download.Progress.BytesReceived * 100 / download.Progress.TotalBytesToReceive;
            });

        }

        private async void GroupDownloadButton_Click(object sender, RoutedEventArgs e)
        {
            //Uri address, address2, address3;

            //Uri.TryCreate(AddressTextBox.Text, UriKind.Absolute, out address);
            //Uri.TryCreate(Address2TextBox.Text, UriKind.Absolute, out address2);
            //Uri.TryCreate(Address3TextBox.Text, UriKind.Absolute, out address3);
            //string destinationFileName = Guid.NewGuid().ToString();
            //string destinationFileName2 = Guid.NewGuid().ToString();
            //string destinationFileName3 = Guid.NewGuid().ToString();
            //StorageFile destinationFile, destinationFile2, destinationFile3;
            //try
            //{
            //    destinationFile = await KnownFolders.VideosLibrary.CreateFileAsync(
            //        destinationFileName, CreationCollisionOption.GenerateUniqueName);

            //    destinationFile2 = await KnownFolders.VideosLibrary.CreateFileAsync(
            //        destinationFileName2, CreationCollisionOption.GenerateUniqueName);

            //    destinationFile3 = await KnownFolders.VideosLibrary.CreateFileAsync(
            //        destinationFileName3, CreationCollisionOption.GenerateUniqueName);
            //}
            //catch (FileNotFoundException ex)
            //{
            //    return;
            //}


            //BackgroundDownloader downloader = new BackgroundDownloader();
            //downloader.TransferGroup = BackgroundTransferGroup.CreateGroup("MyDownloads");

            //DownloadOperation op1 = downloader.CreateDownload(address, destinationFile);
            //DownloadOperation op2 = downloader.CreateDownload(address2, destinationFile2);
            //DownloadOperation op3 = downloader.CreateDownload(address3, destinationFile3);

            //downloader.TransferGroup.TransferBehavior = BackgroundTransferBehavior.Serialized;
            //op1.Priority = BackgroundTransferPriority.High;

            

        }
    }
}
