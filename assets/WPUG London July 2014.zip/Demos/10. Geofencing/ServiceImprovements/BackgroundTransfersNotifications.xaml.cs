﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.Data.Xml.Dom;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Networking.BackgroundTransfer;
using Windows.Storage;
using Windows.UI.Notifications;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace ServiceImprovements
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class BackgroundTransfersNotifications : Page
    {
        private BackgroundTransferGroup mydownloadsGroup;


        public BackgroundTransfersNotifications()
        {
            this.InitializeComponent();

            mydownloadsGroup = 
                BackgroundTransferGroup.CreateGroup("Pluralsight"); // a GUID can be used here as well
            mydownloadsGroup.TransferBehavior = 
                BackgroundTransferBehavior.Parallel;
        }

        private async void GroupDownloadButton_Click(object sender, RoutedEventArgs e)
        {
            BackgroundDownloader backgroundDownloader = 
                new BackgroundDownloader();
            backgroundDownloader.TransferGroup = 
                mydownloadsGroup;

            //Success toast
            XmlDocument successToastXml = 
                ToastNotificationManager.GetTemplateContent
                 (ToastTemplateType.ToastText01);
            successToastXml.GetElementsByTagName("text").Item(0).InnerText =
                "All three downloads completed successfully.";
            ToastNotification successToast = 
                new ToastNotification(successToastXml);
            backgroundDownloader.SuccessToastNotification =
                successToast;

            //Failure toast
            XmlDocument failureToastXml = 
                ToastNotificationManager.GetTemplateContent
                    (ToastTemplateType.ToastText01);
            failureToastXml.GetElementsByTagName("text").Item(0).InnerText =
                "At least one download completed with failure.";
            ToastNotification failureToast = 
                new ToastNotification(failureToastXml);
            backgroundDownloader.FailureToastNotification =
                failureToast;

            // Now create and start downloads for the configured BackgroundDownloader object.
            await RunDownloadsAsync(backgroundDownloader);
        }

        private async System.Threading.Tasks.Task RunDownloadsAsync(BackgroundDownloader backgroundDownloader)
        {
            DownloadOperation[] downloads = new DownloadOperation[3];

            try
            {
                downloads[0] = await CreateDownload(backgroundDownloader, Address1TextBox.Text);
                downloads[1] = await CreateDownload(backgroundDownloader,  Address2TextBox.Text);
                downloads[2] = await CreateDownload(backgroundDownloader, Address3TextBox.Text);
            }
            catch (FileNotFoundException)
            {
                return;
            }

            Task[] downloadTasks = new Task[downloads.Length];
            for (int i = 0; i < downloads.Length; i++)
            {
                downloadTasks[i] = StartDownload(downloads[i]);
            }

            await Task.WhenAll(downloadTasks);
        }

        private async Task<DownloadOperation> CreateDownload(BackgroundDownloader downloader, string address)
        {
            Uri source = new Uri(address, UriKind.Absolute);

            StorageFile destinationFile;
            try
            {
                destinationFile = await KnownFolders.VideosLibrary.CreateFileAsync(
                    Guid.NewGuid().ToString(), CreationCollisionOption.GenerateUniqueName);
            }
            catch (FileNotFoundException ex)
            {
                throw;
            }

            return downloader.CreateDownload(source, destinationFile);
        }


        private async Task StartDownload(DownloadOperation download)
        {

            try
            {
                ResultTextBox.Text += "Starting download." + Environment.NewLine;
                await download.StartAsync();

            }
            catch (TaskCanceledException)
            {
                throw;
            }
        }
    }
}
