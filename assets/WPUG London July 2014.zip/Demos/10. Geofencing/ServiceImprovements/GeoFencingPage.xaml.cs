﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.ApplicationModel.Background;
using Windows.Devices.Geolocation;
using Windows.Devices.Geolocation.Geofencing;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace ServiceImprovements
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class GeoFencingPage : Page
    {
        private Geolocator geolocator = null;
        private Geofence geofence;
        private int fenceCounter;

        public GeoFencingPage()
        {
            this.InitializeComponent();
            geolocator = new Geolocator();
            fenceCounter = 200;
        }

        private async void RegisterBackgroundTaskButton_Click(object sender, RoutedEventArgs e)
        {
            BackgroundAccessStatus backgroundAccessStatus = 
                await BackgroundExecutionManager.RequestAccessAsync();

            BackgroundTaskBuilder geofenceBuilder = 
                new BackgroundTaskBuilder();

            geofenceBuilder.Name = 
                "MyGeofenceBackgroundTask";
            geofenceBuilder.TaskEntryPoint = 
                "SampleLocationTriggers.MyLocationTrigger";

            var trigger = 
                new LocationTrigger(LocationTriggerType.Geofence);
            geofenceBuilder.SetTrigger(trigger);

            IBackgroundTaskRegistration geofenceTask = 
                geofenceBuilder.Register();

        }

        private async void CreateGeofenceButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Geoposition geoposition = 
                    await geolocator.GetGeopositionAsync();

                LatitudeTextBox.Text = 
                    geoposition.Coordinate.Point.Position.Latitude.ToString();
                LongitudeTextBox.Text = 
                    geoposition.Coordinate.Point.Position.Longitude.ToString();

                BasicGeoposition position;
                position.Latitude = 
                    geoposition.Coordinate.Point.Position.Latitude;
                position.Longitude = 
                    geoposition.Coordinate.Point.Position.Longitude;
                position.Altitude = 0.0;
                Geocircle circle = 
                    new Geocircle(position, 1000d, AltitudeReferenceSystem.Surface);

                geofence = 
                    new Geofence(fenceCounter++.ToString(), 
                        circle, 
                        MonitoredGeofenceStates.Entered 
                            | MonitoredGeofenceStates.Exited, 
                            false, TimeSpan.FromSeconds(5));
                GeofenceMonitor.Current.Geofences
                    .Add(geofence);
            }
            catch (Exception ex)
            {
                var a = ex;
                //handle that we don't get the position.
            }
        }
    }
}
