﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Networking.BackgroundTransfer;
using Windows.Storage;
using Windows.Storage.Pickers;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace Win8Downloader
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        private CancellationTokenSource uploadCancellationTokenSource;
        public MainPage()
        {
            this.InitializeComponent();
            uploadCancellationTokenSource = new CancellationTokenSource();
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.  The Parameter
        /// property is typically used to configure the page.</param>
        protected  override void OnNavigatedTo(NavigationEventArgs e)
        {
            
        }

        #region Download

        private async void DownloadButton1_Click_1(object sender, RoutedEventArgs e)
        {
            string uriString = UriTextBox1.Text.Trim();
            Uri uri = null;
            if (Uri.TryCreate(uriString, UriKind.Absolute, out uri))
            {
                string fileName = CreateFileName(uri);
                var download = await CreateDownload(uri, fileName);
                await PerformDownload(download);
            }
            else
            {
                StatusTextBlock1.Text = "Invalid URI";
            }
        }

        private async void DownloadButton2_Click_1(object sender, RoutedEventArgs e)
        {
            string uriString = UriTextBox2.Text.Trim();
            Uri uri = null;
            if (Uri.TryCreate(uriString, UriKind.Absolute, out uri))
            {
                string fileName = CreateFileName(uri);
                var download = await CreateDownload(uri, fileName);
                await PerformDownload(download);
            }
            else
            {
                StatusTextBlock1.Text = "Invalid URI";
            }
        }

        private async Task<DownloadOperation> CreateDownload(Uri uri, string fileName)
        {
            StorageFile storageFile = await KnownFolders.VideosLibrary.CreateFileAsync(fileName, CreationCollisionOption.GenerateUniqueName);

            BackgroundDownloader downloader = new BackgroundDownloader();
            return downloader.CreateDownload(uri, storageFile);
        }

        private string CreateFileName(Uri uri)
        {
            return Path.GetFileName(uri.LocalPath);
        }

        private async Task PerformDownload(DownloadOperation download)
        {
            await download.StartAsync();
        }

        #endregion
        
        #region Upload

        private async void SelectFileButton_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                var picker = new FileOpenPicker();
                picker.FileTypeFilter.Add(".jpg");
                var selectedFile = await picker.PickSingleFileAsync();

                if (selectedFile != null)
                {
                    Progress<UploadOperation> uploadProgressCallback = 
                        new Progress<UploadOperation>(UploadProgress);
                    BackgroundUploader backgroundUploader = new BackgroundUploader();
                    backgroundUploader
                        .SetRequestHeader("Filename", selectedFile.Name);

                    var uploadOperation = backgroundUploader.CreateUpload(new Uri("http://posttestserver.com/post.php", UriKind.Absolute), selectedFile);

                    var result = 
                        await uploadOperation.StartAsync()
                        .AsTask(uploadCancellationTokenSource.Token, 
                                    uploadProgressCallback);
                }
            }
            catch (Exception ex)
            {
                string a = ex.Message;
            }
            
        }

        private void UploadProgress(UploadOperation uploadOperation)
        {
            if (uploadOperation.Progress.TotalBytesToSend > 0)
            {
                var ignore = this.Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, () =>
                {
                    UploadProgressBar.Value = 
                        uploadOperation.Progress.BytesSent * 100 / 
                        uploadOperation.Progress.TotalBytesToSend;
                });
            }
        }

        #endregion

        #region Download management

        private void CancelAllDownloadsButton_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void ResumeAllDownloadsButton_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void PauseAllDownloadsButton_Click_1(object sender, RoutedEventArgs e)
        {

        }

        #endregion

        #region DownloadProgress

        private void UpdateDownloadProgress(DownloadOperation downloadOperation)
        {

        }

        #endregion

        #region Cancel downloads


        private void CancelDownload1_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void CancelDownload2_Click_1(object sender, RoutedEventArgs e)
        {

        }
        #endregion

    }
}
