﻿using ReportingApp.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Serialization;
using Windows.ApplicationModel.Background;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.Storage.Streams;
using Windows.UI.Core;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace ReportingApp
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        private Report report;
        public MainPage()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.  The Parameter
        /// property is typically used to configure the page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            InitializeReport();

            UnregisterBackgroundTask();

            RegisterBackgroundTask();
        }

        private void UnregisterBackgroundTask()
        {
            foreach (var task in BackgroundTaskRegistration.AllTasks)
            {
                if (task.Value.Name == "ReportBackgroundTask")
                {
                    BackgroundTaskHelper.UnregisterBackgroundTasks("ReportBackgroundTask");
                }
            }

            StatusTextBox.Text += "Task unregistered\n";
        }

        private void RegisterBackgroundTask()
        {
            SystemTrigger internetAvailableTrigger = 
                new SystemTrigger(SystemTriggerType.InternetAvailable, false);
            SystemCondition internetAvailablecondition = 
                new SystemCondition(SystemConditionType.InternetAvailable);

            BackgroundTaskRegistration task = 
                BackgroundTaskHelper.RegisterBackgroundTask
                ("Tasks.ReportBackgroundTask",
                 "ReportBackgroundTask",
                 internetAvailableTrigger,
                 internetAvailablecondition);

            StatusTextBox.Text += "Task registered\n";

            task.Progress += task_Progress;
            task.Completed += task_Completed;
        }

        async void task_Completed(BackgroundTaskRegistration sender, BackgroundTaskCompletedEventArgs args)
        {
            await Dispatcher.RunAsync(CoreDispatcherPriority.Normal,
            () =>
            {
                StatusTextBox.Text += "The background task completed";
            });
        }

        async void task_Progress(BackgroundTaskRegistration sender, BackgroundTaskProgressEventArgs args)
        {
            await Dispatcher.RunAsync(CoreDispatcherPriority.Normal,
            () =>
            {
                StatusTextBox.Text += String.Format("Progress: {0}%\n", args.Progress);
            });
        }

        private void InitializeReport()
        {
            report = new Report();
            report.ReportId = Guid.NewGuid();
            ReportGrid.DataContext = report;
        }

        private async void SaveReportButton_Click_1(object sender, RoutedEventArgs e)
        {
            if (FirstNameTextBox.Text != string.Empty &&
                LastNameTextBox.Text != string.Empty &&
                CurrentJobTextBox.Text != string.Empty &&
                DescriptionTextBox.Text != string.Empty &&
                RecommendationTextBox.Text != string.Empty)
            {
                await Serialize(report);
                MessageDialog messageDialog = new MessageDialog("Report saved successfully");
                await messageDialog.ShowAsync();
                InitializeReport();
            }
            else
            {
                ReportStatusBlock.Text = "Not all required fields are filled in!";
            }
        }

        private static async System.Threading.Tasks.Task Serialize(Report report)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(Report));

            StorageFolder storageFolder = ApplicationData.Current.LocalFolder;

            StorageFile file = await storageFolder.CreateFileAsync(report.ReportId + ".xml", CreationCollisionOption.ReplaceExisting);

            IRandomAccessStream randomAccessStream = await file.OpenAsync(FileAccessMode.ReadWrite);
            IOutputStream outputStream = randomAccessStream.GetOutputStreamAt(0);

            using (Stream stream = outputStream.AsStreamForWrite())
            {
                xmlSerializer.Serialize(stream, report);
                await outputStream.FlushAsync();
            }
        }
    }
}
