﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace ReportingApp.Services
{
    [DataContract]
    public class Report
    {
        [DataMember]
        public Guid ReportId { get; set; }
        [DataMember]
        public string FirstName { get; set; }
        [DataMember]
        public string LastName { get; set; }
        [DataMember]
        public string Description { get; set; }
        [DataMember]
        public string CurrentJob { get; set; }
        [DataMember]
        public string Recommendation { get; set; } 
    }
}