﻿using ReportingApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using Windows.ApplicationModel.Background;
using Windows.Storage;
using Windows.Storage.Streams;
using System.IO;
using System.Diagnostics;


namespace Tasks
{
    public sealed class ReportBackgroundTask : IBackgroundTask
    {
        volatile bool cancelRequested = false;
        BackgroundTaskDeferral deferral = null;
        uint progress = 0;
        IBackgroundTaskInstance backgroundTaskInstance = null;

        public async void Run(IBackgroundTaskInstance taskInstance)
        {
            backgroundTaskInstance = taskInstance;

            taskInstance.Canceled += taskInstance_Canceled;
            deferral = taskInstance.GetDeferral();

            List<Report> allReports = await ReadAllXmlReports();
        }

        private async Task<List<Report>> ReadAllXmlReports()
        {
            backgroundTaskInstance.Progress = 0; 

            Debug.WriteLine("ReadAllXmlReports starting");
            StorageFolder storageFolder = ApplicationData.Current.LocalFolder;
            List<Report> reports = new List<Report>();
            List<ReportingService.Report> serviceReports = new List<ReportingService.Report>();

            try
            {
                IReadOnlyList<StorageFile> files = await storageFolder.GetFilesAsync();

                //let's divide 50% of the progress over the amount of files
                int fileCount = files.Count;
                uint interval = (uint)Math.Round((double)(50 / fileCount));

                foreach (var file in files)
                {
                    backgroundTaskInstance.Progress += interval;
                    Debug.WriteLine("Reading report");
                    IInputStream inputStream = await file.OpenReadAsync();
                    XmlSerializer xmlSerializer = new XmlSerializer(typeof(Report));

                    Report report = (Report)xmlSerializer.Deserialize(inputStream.AsStreamForRead());
                    reports.Add(report);
                    inputStream.Dispose();

                    Debug.WriteLine("Report read");
                }

                Debug.WriteLine("ReadAllXmlReports finished");

                ConvertReportsToServiceReports(reports, serviceReports);
                backgroundTaskInstance.Progress = 75;
                Debug.WriteLine("Conversion done");

                Debug.WriteLine("Service communication started");

                ReportingService.ReportingServiceClient reportingServiceClient = new ReportingService.ReportingServiceClient();
                bool result = await reportingServiceClient.UploadReportsAsync(serviceReports);

                backgroundTaskInstance.Progress = 100;
                Debug.WriteLine("Service communication finished");

                return reports;
            }
            catch (FileNotFoundException ex)
            {
                return null;
            }
            finally
            {
                deferral.Complete();
            }
        }

        private void ConvertReportsToServiceReports(List<Report> reports, List<ReportingService.Report> serviceReports)
        {
            foreach (var item in reports)
            {
                ReportingService.Report serviceReport = new ReportingService.Report()
                {
                    ReportId = item.ReportId,
                    FirstName = item.FirstName,
                    LastName = item.LastName,
                    Description = item.Description,
                    CurrentJob = item.CurrentJob,
                    Recommendation = item.Recommendation
                };
                serviceReports.Add(serviceReport);
            }
        }

        void taskInstance_Canceled(IBackgroundTaskInstance sender, BackgroundTaskCancellationReason reason)
        {
            //save state of the task
        }
    }
}
