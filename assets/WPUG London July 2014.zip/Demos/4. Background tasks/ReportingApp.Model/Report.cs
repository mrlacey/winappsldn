﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReportingApp.Model
{
    public sealed class Report: INotifyPropertyChanged
    {
        private Guid reportId;
        private string firstName;
        private string lastName;
        private string description;
        private string currentJob;
        private string recommendation;

        public Guid ReportId 
        {
            get
            {
                return reportId;
            }
            set
            {
                reportId = value;
                RaisePropertyChanged("ReportId");
            }
        }

        public string FirstName
        {
            get
            {
                return firstName;
            }
            set
            {
                firstName = value;
                RaisePropertyChanged("FirstName");
            }
        }
            
        public string LastName
        {
            get
            {
                return lastName;
            }
            set
            {
                lastName = value;
                RaisePropertyChanged("LastName");
            }
        }

        public string CurrentJob
        {
            get
            {
                return currentJob;
            }
            set
            {
                currentJob = value;
                RaisePropertyChanged("CurrentJob");
            }
        }

        public string Description
        {
            get
            {
                return description;
            }
            set
            {
                description = value;
                RaisePropertyChanged("Description");
            }
        }

        public string Recommendation
        {
            get
            {
                return recommendation;
            }
            set
            {
                recommendation = value;
                RaisePropertyChanged("Recommendation");
            }
        }

        public void RaisePropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
