﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.ApplicationModel.Background;
using Windows.Data.Xml.Dom;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Notifications;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace NewWinRTAPIs
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class AlarmPage : Page
    {
        private AlarmAccessStatus alarmAccessStatus;
        public AlarmPage()
        {
            this.InitializeComponent();
        }

        protected async override void OnNavigatedTo(NavigationEventArgs e)
        {
            alarmAccessStatus =
                AlarmApplicationManager.GetAccessStatus();
            bool shouldAskUser = false;

            switch (alarmAccessStatus)
            {
                case AlarmAccessStatus
                        .AllowedWithWakeupCapability:
                    // Already OK
                    break;
                case AlarmAccessStatus
                        .AllowedWithoutWakeupCapability:
                    // Not 100% OK but already done
                    break;
                case AlarmAccessStatus
                        .Denied:
                    // Previously denied
                    break;
                case AlarmAccessStatus
                        .Unspecified:
                    shouldAskUser = true;
                    break;
                default:
                    break;
            }
            if (shouldAskUser)
            {
                alarmAccessStatus =
                    await AlarmApplicationManager
                        .RequestAccessAsync();
            }
        }

        private void AddAlarmButton_Click(object sender, RoutedEventArgs e)
        {
            if (alarmAccessStatus == 
                AlarmAccessStatus.AllowedWithWakeupCapability || alarmAccessStatus == AlarmAccessStatus.AllowedWithoutWakeupCapability)
            {

                string alarmReason = "Wife's birthday";

                string toastXmlString =
                    "<toast duration=\"long\">\n" +
                        "<visual>\n" +
                            "<binding template=\"ToastText02\">\n" +
                                "<text id=\"1\">Reminder</text>\n" +
                                "<text id=\"2\">" + alarmReason + "</text>\n" +
                            "</binding>\n" +
                        "</visual>\n" +
                        "<commands scenario=\"alarm\">\n" +
                            "<command id=\"snooze\"/>\n" +
                            "<command id=\"dismiss\"/>\n" +
                        "</commands>\n" +
                        "<audio src=\"ms-winsoundevent:Notification.Looping.Alarm2\" loop=\"true\" />\n" +
                    "</toast>\n";

                XmlDocument doc = new XmlDocument();
                doc.LoadXml(toastXmlString);

                ToastNotifier toastNotifier = 
                    ToastNotificationManager.CreateToastNotifier();

                ScheduledToastNotification toast = 
                    new Windows.UI.Notifications.ScheduledToastNotification(doc, DateTime.Now.AddSeconds(15), TimeSpan.FromSeconds(60), 2);
                toastNotifier.AddToSchedule(toast);
            }
        }

    }
}
