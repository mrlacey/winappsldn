﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SnailMail.WPFClient
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

           
        }

        private void SendRawMessageButton_Click_1(object sender, RoutedEventArgs e)
        {
            WnsAuthentication.OAuthToken token = WnsAuthentication.GetAccessToken(ClientSecretTextBox.Text, SIDTextBox.Text);
            MessageTextBlock.Text = SendRawNotification(token);
        }

        private string SendRawNotification(WnsAuthentication.OAuthToken token)
        {
            string type = string.Empty;
            string toastMessage = string.Empty;
            bool result = false;

            try
            {
                type = "wns/raw";

                MailService.MailServiceClient client = new MailService.MailServiceClient();
                var mails = client.GetMailsForCustomer(new Guid("{E7BD05AC-DD3C-4904-A4A3-1E7C4C9421D0}"));
                int count = mails.Count();

                toastMessage = string.Format("You have {0} new mails",count);

                byte[] contentInBytes = Encoding.UTF8.GetBytes(toastMessage);

                var request = (HttpWebRequest)WebRequest.Create(new Uri(UriTextBox.Text));
                request.Method = "POST";
                request.ContentType = "application/octet-stream";
                request.Headers = new WebHeaderCollection();
                request.Headers.Add("X-WNS-Type", type);
                request.Headers.Add("Authorization", "Bearer " + token.AccessToken);

                request.ContentLength = toastMessage.Length;

                using (Stream requestStream = request.GetRequestStream())
                {
                    requestStream.Write(contentInBytes, 0, toastMessage.Length);
                }

                var response = (HttpWebResponse)request.GetResponse();
                return response.StatusCode.ToString();
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        private void AddNewMailButton_Click_1(object sender, RoutedEventArgs e)
        {
            MailService.MailServiceClient client = new MailService.MailServiceClient();
            client.AddMail("John Smith", "Gill Cleeren", "Your Pluralsight course", "Lorem Ipsum", DateTime.Now, new Guid("{E7BD05AC-DD3C-4904-A4A3-1E7C4C9421D0}"));
        }
    }
}
