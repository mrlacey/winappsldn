﻿using NotificationsExtensions.TileContent;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Windows.ApplicationModel.Background;
using Windows.Data.Xml.Dom;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.UI.Core;
using Windows.UI.Notifications;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace SnailMail
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        private CoreDispatcher dispatcher;

        public MainPage()
        {
            this.InitializeComponent();

            dispatcher = Window.Current.Dispatcher;
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.  The Parameter
        /// property is typically used to configure the page.</param>
        protected async override void OnNavigatedTo(NavigationEventArgs e)
        {
            BackgroundAccessStatus backgroundAccessStatus = BackgroundExecutionManager.GetAccessStatus();

             if (backgroundAccessStatus == BackgroundAccessStatus.Unspecified)
                 backgroundAccessStatus = await BackgroundExecutionManager.RequestAccessAsync();

            if (backgroundAccessStatus == BackgroundAccessStatus.AllowedMayUseActiveRealTimeConnectivity ||
                backgroundAccessStatus == BackgroundAccessStatus.AllowedWithAlwaysOnRealTimeConnectivity)
            {
                MailService.MailServiceClient client = new MailService.MailServiceClient();
                var mails = await client.GetUnreadMailsForCustomerAsync(new Guid("{E7BD05AC-DD3C-4904-A4A3-1E7C4C9421D0}"));

                int count = mails.Count; 

                var channelUri = await Windows.Networking.PushNotifications.PushNotificationChannelManager.CreatePushNotificationChannelForApplicationAsync();

                //now send the channel URI and the customer ID to the service
                MailService.MailServiceClient mailServiceClient = new MailService.MailServiceClient();
                bool success = await mailServiceClient.RegisterChannelUriAsync(new Guid("{E7BD05AC-DD3C-4904-A4A3-1E7C4C9421D0}"), channelUri.Uri);

                UnregisterBackgroundTask();

                RegisterBackgroundTask();

                ReadRawMessageFromSettings();
            }
        }

        private void ReadRawMessageFromSettings()
        {
            ApplicationDataContainer container = ApplicationData.Current.LocalSettings;
            if(container.Values.ContainsKey("RawMessage"))
            {
                NewMailTextBlock.Text = container.Values["RawMessage"].ToString();
            }
        }

        private void UnregisterBackgroundTask()
        {
            foreach (var task in BackgroundTaskRegistration.AllTasks)
            {
                if (task.Value.Name == "MailBackgroundTask")
                {
                    BackgroundTaskHelper.UnregisterBackgroundTasks("MailBackgroundTask");
                }
            }

            StatusTextBlock.Text += "Task unregistered\n";
        }

        private void RegisterBackgroundTask()
        {
            PushNotificationTrigger pushNotificationTrigger = new PushNotificationTrigger();

            var task = BackgroundTaskHelper.RegisterBackgroundTask("Tasks.MailTask",
                                                                   "MailBackgroundTask",
                                                                   pushNotificationTrigger,
                                                                   null);
            StatusTextBlock.Text = "Task registered";
            task.Completed += task_Completed;
           
        }

        async void task_Completed(BackgroundTaskRegistration sender, BackgroundTaskCompletedEventArgs args)
        {
            await dispatcher.RunAsync(CoreDispatcherPriority.Normal, () =>
            {
                StatusTextBlock.Text = "Notification received";
            });
        }
    }
}
