﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.ApplicationModel.Background;
using Windows.Networking.PushNotifications;
using Windows.Storage;

namespace Tasks
{
    public sealed class MailTask : IBackgroundTask
    {
        public void Run(IBackgroundTaskInstance taskInstance)
        {
            RawNotification notification = 
                (RawNotification)taskInstance.TriggerDetails;
            ApplicationDataContainer container = 
                ApplicationData.Current.LocalSettings;
            container.Values["RawMessage"] = notification.Content.ToString();
        }
    }
}
