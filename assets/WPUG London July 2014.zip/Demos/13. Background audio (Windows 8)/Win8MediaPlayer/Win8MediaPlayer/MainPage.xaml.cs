﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Media;
using Windows.Storage;
using Windows.Storage.Pickers;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace Win8MediaPlayer
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        private StorageFile selectedFile;
        private bool isPlaying;
        private CoreWindow coreWindow = Window.Current.CoreWindow;

        public MainPage()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.  The Parameter
        /// property is typically used to configure the page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            isPlaying = false;
        }

        private async void SelectFileButton_Click_1(object sender, RoutedEventArgs e)
        {
            var picker = new FileOpenPicker();
            picker.FileTypeFilter.Add(".mp3");
            selectedFile = await picker.PickSingleFileAsync();

            BackgroundEnabledMediaElement.SetSource(await selectedFile.OpenAsync(FileAccessMode.Read), "mp3");

            MediaControl.PlayPressed += MediaControl_PlayPressed;
            MediaControl.StopPressed += MediaControl_StopPressed;
            MediaControl.PausePressed += MediaControl_PausePressed;
            MediaControl.PlayPauseTogglePressed += MediaControl_PlayPauseTogglePressed;

            MediaControl.ArtistName = "Gill Cleeren";
        }

        async void MediaControl_PlayPauseTogglePressed(object sender, object e)
        {
            await Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, () =>
            {
                try
                {
                    if (BackgroundEnabledMediaElement.CurrentState == MediaElementState.Paused)
                    {
                        BackgroundEnabledMediaElement.Play();
                        MediaControl.IsPlaying = true;
                    }
                    else
                    {
                        BackgroundEnabledMediaElement.Pause();
                        MediaControl.IsPlaying = false;
                    }
                }
                catch
                {
                }
            });
        }

        async void MediaControl_PausePressed(object sender, object e)
        {
            await Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, () =>
                {
                    MediaControl.IsPlaying = false;
                    BackgroundEnabledMediaElement.Pause();
                }
            );
        }

        async void MediaControl_StopPressed(object sender, object e)
        {
            await Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, () =>
            {
                MediaControl.IsPlaying = false;
                BackgroundEnabledMediaElement.Stop();
            }
            );
        }

        async void MediaControl_PlayPressed(object sender, object e)
        {
            await Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, () =>
                {
                    BackgroundEnabledMediaElement.Play();
                    MediaControl.IsPlaying = true;
                }
                    );
        }

        private void PlayButton_Click_1(object sender, RoutedEventArgs e)
        {
            MediaControl.IsPlaying = true;
            BackgroundEnabledMediaElement.Play();
            MediaControl.TrackName = selectedFile.Name;
            StatusTextBox.Text += "Playing...\r\n";
        }

        private void PauseButton_Click_1(object sender, RoutedEventArgs e)
        {
            MediaControl.IsPlaying = false;
            BackgroundEnabledMediaElement.Pause();
            StatusTextBox.Text += "Pausing...\r\n";
        }

        private void StopButton_Click_1(object sender, RoutedEventArgs e)
        {
            MediaControl.IsPlaying = false;
            BackgroundEnabledMediaElement.Stop();
            StatusTextBox.Text += "Stop playback...\r\n";
        }


    }
}
