﻿using NotificationsExtensions.BadgeContent;
using NotificationsExtensions.TileContent;
using NotificationsExtensions.ToastContent;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.ApplicationModel.Background;
using Windows.Networking.PushNotifications;
using Windows.Storage;
using Windows.UI.Notifications;

namespace Tasks
{
    public sealed class MailTask : IBackgroundTask
    {
        public async void Run(IBackgroundTaskInstance taskInstance)
        {
            var deferral = taskInstance.GetDeferral();

            MailService.MailServiceClient client = new MailService.MailServiceClient();
            var mails = await client.GetUnreadMailsForCustomerAsync(new Guid("{E7BD05AC-DD3C-4904-A4A3-1E7C4C9421D0}"));

            if (mails.Count > 0)
            {
                ITileWideText01 tileContent = TileContentFactory.CreateTileWideText01();
                tileContent.TextHeading.Text = "New Snail Mails";
                tileContent.TextBody1.Text = mails[0].Subject;

                if (mails.Count > 1)
                    tileContent.TextBody2.Text = mails[1].Subject;

                if (mails.Count >= 2)
                    tileContent.TextBody3.Text = mails[2].Subject;

                if (mails.Count >= 3)
                    tileContent.TextBody4.Text = mails[3].Subject;

                ITileSquareText04 squareContent = TileContentFactory.CreateTileSquareText04();
                squareContent.TextBodyWrap.Text = "New Snail Mails";
                tileContent.SquareContent = squareContent;

                TileUpdateManager.CreateTileUpdaterForApplication().Update(tileContent.CreateNotification());

            }

            deferral.Complete();
        }
    }
}
