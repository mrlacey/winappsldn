﻿using NotificationsExtensions.TileContent;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Windows.ApplicationModel.Background;
using Windows.Data.Xml.Dom;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.UI.Core;
using Windows.UI.Notifications;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace SnailMail
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        private CoreDispatcher dispatcher;

        public MainPage()
        {
            this.InitializeComponent();

            dispatcher = Window.Current.Dispatcher;
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.  The Parameter
        /// property is typically used to configure the page.</param>
        protected async override void OnNavigatedTo(NavigationEventArgs e)
        {
            BackgroundAccessStatus backgroundAccessStatus = BackgroundExecutionManager.GetAccessStatus();

             if (backgroundAccessStatus == BackgroundAccessStatus.Unspecified)
                 backgroundAccessStatus = await BackgroundExecutionManager.RequestAccessAsync();

            if (backgroundAccessStatus == BackgroundAccessStatus.AllowedMayUseActiveRealTimeConnectivity ||
                backgroundAccessStatus == BackgroundAccessStatus.AllowedWithAlwaysOnRealTimeConnectivity)
            {
                UnregisterBackgroundTask();

                RegisterBackgroundTask();
            }
        }

       

        private void UnregisterBackgroundTask()
        {
            foreach (var task in BackgroundTaskRegistration.AllTasks)
            {
                if (task.Value.Name == "MailBackgroundTask")
                {
                    BackgroundTaskHelper.UnregisterBackgroundTasks("MailBackgroundTask");
                }
            }

            StatusTextBlock.Text += "Task unregistered\n";
        }

        private void RegisterBackgroundTask()
        {
            TimeTrigger timeTrigger = new TimeTrigger(15, false);

            var task = 
                BackgroundTaskHelper.RegisterBackgroundTask
                ("Tasks.MailTask",
                 "MailBackgroundTask",
                 timeTrigger,
                 null);

            task.Completed += task_Completed;
            StatusTextBlock.Text += "Task registered\n";
        }

        async void task_Completed(BackgroundTaskRegistration sender, BackgroundTaskCompletedEventArgs args)
        {
            await dispatcher.RunAsync(CoreDispatcherPriority.Normal, () =>
            {
                StatusTextBlock.Text = "Time trigger executed";
            });
        }

        private void CreateTileUpdate(int count)
        {
            ITileWideSmallImageAndText03 tileContent = TileContentFactory.CreateTileWideSmallImageAndText03();
            tileContent.TextBodyWrap.Text = string.Format("You have {0} new mails", count.ToString());
            tileContent.Image.Src = "ms-appx:///assets/widelogo.png";
            tileContent.RequireSquareContent = false;
            TileUpdateManager.CreateTileUpdaterForApplication().Update(tileContent.CreateNotification());
        }

        private static void CreateBadgeUpdate(int count)
        {
            string xml = "<badge value='badgevalue'/>";

            xml = xml.Replace("badgevalue", count.ToString());

            XmlDocument xmlDocument = new Windows.Data.Xml.Dom.XmlDocument();
            xmlDocument.LoadXml(xml);

            BadgeNotification badge = new BadgeNotification(xmlDocument);
            BadgeUpdateManager.CreateBadgeUpdaterForApplication().Update(badge);
        }
    }
}
