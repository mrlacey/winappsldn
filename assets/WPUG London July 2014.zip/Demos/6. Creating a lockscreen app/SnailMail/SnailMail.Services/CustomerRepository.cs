﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SnailMail.Services
{
    public class CustomerRepository
    {
        private static List<Customer> AllCustomers;
        private static CustomerRepository customerRepository;

        private CustomerRepository()
        {
            AllCustomers = new List<Customer>();
        }

        public static CustomerRepository CreateInstance()
        {
            if (customerRepository == null)
            {
                customerRepository = new CustomerRepository();
            }

            return customerRepository;
        }

        public void AddCustomer(Customer c)
        {
            AllCustomers.Add(c);
        }
    }
}