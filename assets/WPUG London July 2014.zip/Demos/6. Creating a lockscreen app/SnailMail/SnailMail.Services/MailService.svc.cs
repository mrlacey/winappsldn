﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace SnailMail.Services
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "MailService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select MailService.svc or MailService.svc.cs at the Solution Explorer and start debugging.
    public class MailService : IMailService
    {
        public void RegisterChannelUri(Guid customerGuid, string channelUri)
        {
            Customer c = new Customer();
            c.ChannelUri = channelUri;
            c.CustomerGuid = customerGuid;
            CustomerRepository.CreateInstance().AddCustomer(c);
        }

        public List<Mail> GetMailsForCustomer(Guid customerGuid)
        {
            return MailRepository.CreateInstance().AllMails.Where(m => m.CustomerGuid == customerGuid).ToList();
        }

        public List<Mail> GetUnreadMailsForCustomer(Guid customerGuid)
        {
            return MailRepository.CreateInstance().AllMails.Where(m => m.CustomerGuid == customerGuid && m.IsRead == false).ToList();  
        }

        public void AddMail(string from, string to, string subject, string body, DateTime sendDate, Guid customerGuid)
        {
            Mail m = new Mail() { From = from, To = to, CustomerGuid = customerGuid, SendDate = sendDate, Body = body, Subject = subject, MailId = Guid.NewGuid() };
            MailRepository.CreateInstance().AddMail(m);

            //send push notifications
        }
    }
}
