﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace SnailMail.Services
{
    [DataContract]
    public class Mail
    {
        [DataMember]
        public Guid MailId { get; set; }

        [DataMember]
        public Guid CustomerGuid { get; set; }

        [DataMember]
        public string From { get; set; }

        [DataMember]
        public string To { get; set; }

        [DataMember]
        public string Subject { get; set; }

        [DataMember]
        public DateTime SendDate { get; set; }

        [DataMember]
        public string Body { get; set; }

        [DataMember]
        public bool IsRead { get; set; }

    }
}