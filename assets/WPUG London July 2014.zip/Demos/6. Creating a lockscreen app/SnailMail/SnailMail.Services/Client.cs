﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SnailMail.Services
{
    public class Customer
    {
        public string ChannelUri { get; set; }
        public Guid CustomerGuid { get; set; }
    }
}