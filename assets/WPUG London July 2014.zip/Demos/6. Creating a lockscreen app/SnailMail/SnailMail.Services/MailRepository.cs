﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SnailMail.Services
{
    public class MailRepository
    {
        private static List<Mail> allMails;
        private static MailRepository mailRepository;

        private MailRepository()
        {
            allMails = new List<Mail>();
        }

        public static MailRepository CreateInstance()
        {
            if (mailRepository == null)
            {
                mailRepository = new MailRepository();
                CreateDefaultMails();
            }

            return mailRepository;
        }

        private static void CreateDefaultMails()
        {
            Mail mail1 = new Mail() { MailId = new Guid("{EB332984-6A59-496F-B74D-F73CD2A5D39C}"), From = "AAA BBB", To = "CCC DDD", Subject = "Look at this!", Body = "Lorem ispum...", SendDate = DateTime.Now, CustomerGuid = new Guid("{E7BD05AC-DD3C-4904-A4A3-1E7C4C9421D0}"), IsRead = false };
            Mail mail2 = new Mail() { MailId = new Guid("{126CA1FB-CD37-430A-B9D0-90E6243B003C}"), From = "EEE OOO", To = "CCC DDD", Subject = "Amazing", Body = "Lorem ispum...", SendDate = DateTime.Now, CustomerGuid = new Guid("{E7BD05AC-DD3C-4904-A4A3-1E7C4C9421D0}"), IsRead = false };
            Mail mail3 = new Mail() { MailId = new Guid("{ACA1361B-14DF-49D9-97DB-87A87D4003DC}"), From = "GGG NNN", To = "CCC DDD", Subject = "RE: Tomorrow", Body = "Lorem ispum...", SendDate = DateTime.Now, CustomerGuid = new Guid("{E7BD05AC-DD3C-4904-A4A3-1E7C4C9421D0}"), IsRead = false };
            Mail mail4 = new Mail() { MailId = new Guid("{92F4A4B3-5FFE-4CF8-A392-99600989109E}"), From = "HHH JJJ", To = "CCC DDD", Subject = "FW: Account status", Body = "Lorem ispum...", SendDate = DateTime.Now, CustomerGuid = new Guid("{E7BD05AC-DD3C-4904-A4A3-1E7C4C9421D0}"), IsRead = false };

            allMails.Add(mail1);
            allMails.Add(mail2);
            allMails.Add(mail3);
            allMails.Add(mail4);
        }

        public void AddMail(Mail m)
        {
            allMails.Add(m);
        }
        public List<Mail> AllMails
        {
            get
            {
                return allMails;
            }
        }
    }
}